<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    //
    // function contact(Request $req){
    //     $user=new User;
    //     $user->name=$req->input('name');
    //     $user->email=$req->input('email');
    //     $user->mobile=$req->input('mobile');
    //     $user->descrpation=$req->input('descrpation');
    //     $user->file_path=$req->file("file")->store('contacts');
    //     $user->save();

    //     return $user;
    //}
}
